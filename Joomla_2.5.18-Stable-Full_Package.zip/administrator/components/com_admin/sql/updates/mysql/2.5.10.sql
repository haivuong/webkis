UPDATE `#__extensions` SET `protected` = 0 WHERE `name` = 'mod_banners';
